import React, { useState, useMemo } from 'react';
import { useCurrency } from '../../context/CurrencyContext';
import { usePrivacy } from '../../context/PrivacyContext';
import { Calculator, Rocket } from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

export const WealthSimulatorView: React.FC = () => {
  const { symbol, formatAmount } = useCurrency();
  const { isPrivacyMasked } = usePrivacy();

  const [monthlyDeposit, setMonthlyDeposit] = useState<number>(15000);
  const [annualReturn, setAnnualReturn] = useState<number>(12); // 12% standard Nifty/Mutual Funds
  const [years, setYears] = useState<number>(10);

  const simulation = useMemo(() => {
    const monthlyRate = annualReturn / 100 / 12;
    const totalMonths = years * 12;

    let futureValue = 0;
    const chartData = [];

    let currentInvested = 0;
    let currentWealth = 0;

    for (let yr = 1; yr <= years; yr++) {
      const months = yr * 12;
      currentInvested = monthlyDeposit * months;
      
      // Future Value of a Series: FV = P * [ ((1 + r)^n - 1) / r ] * (1 + r)
      if (monthlyRate > 0) {
        currentWealth = monthlyDeposit * ((Math.pow(1 + monthlyRate, months) - 1) / monthlyRate) * (1 + monthlyRate);
      } else {
        currentWealth = currentInvested;
      }

      chartData.push({
        year: `Year ${yr}`,
        invested: Math.round(currentInvested),
        wealth: Math.round(currentWealth),
        returns: Math.round(currentWealth - currentInvested)
      });
    }

    futureValue = currentWealth;
    const totalInvested = monthlyDeposit * totalMonths;
    const wealthGain = futureValue - totalInvested;
    const multiplier = totalInvested > 0 ? (futureValue / totalInvested).toFixed(1) : '1.0';

    return {
      chartData,
      totalInvested,
      futureValue,
      wealthGain,
      multiplier
    };
  }, [monthlyDeposit, annualReturn, years]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      
      {/* Header */}
      <div className="glass-panel" style={{ padding: '24px', display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'center', gap: '16px' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div style={{ width: '36px', height: '36px', borderRadius: '10px', background: 'rgba(16, 185, 129, 0.15)', color: 'var(--accent-emerald)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Calculator size={20} />
            </div>
            <div>
              <h2 style={{ fontSize: '18px', fontWeight: 700, color: 'var(--text-primary)' }}>
                Wealth & SIP Simulator (What-If Lab)
              </h2>
              <p style={{ fontSize: '13px', color: 'var(--text-muted)' }}>
                Simulate compound interest and future corpus growth
              </p>
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', background: 'rgba(16, 185, 129, 0.12)', border: '1px solid rgba(16, 185, 129, 0.25)', padding: '6px 14px', borderRadius: 'var(--radius-full)', color: 'var(--accent-emerald-light)', fontSize: '12px', fontWeight: 700 }}>
          <Rocket size={14} />
          <span>{simulation.multiplier}x Wealth Multiplier</span>
        </div>
      </div>

      {/* Sliders Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '16px' }}>
        
        {/* Monthly Investment Slider */}
        <div className="glass-panel" style={{ padding: '20px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <span style={{ fontSize: '13px', color: 'var(--text-secondary)', fontWeight: 600 }}>
              Monthly SIP / Savings
            </span>
            <span className={`font-mono ${isPrivacyMasked ? 'privacy-masked' : ''}`} style={{ fontSize: '18px', fontWeight: 800, color: 'var(--accent-emerald-light)' }}>
              {symbol}{monthlyDeposit.toLocaleString('en-IN')}
            </span>
          </div>
          <input
            type="range"
            min="1000"
            max="100000"
            step="1000"
            value={monthlyDeposit}
            onChange={e => setMonthlyDeposit(Number(e.target.value))}
            style={{ width: '100%', accentColor: 'var(--accent-emerald)', cursor: 'pointer' }}
          />
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: 'var(--text-muted)', marginTop: '6px' }}>
            <span>{symbol}1,000</span>
            <span>{symbol}50,000</span>
            <span>{symbol}1,00,000</span>
          </div>
        </div>

        {/* Expected Return Slider */}
        <div className="glass-panel" style={{ padding: '20px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <span style={{ fontSize: '13px', color: 'var(--text-secondary)', fontWeight: 600 }}>
              Expected Annual Return
            </span>
            <span className="font-mono" style={{ fontSize: '18px', fontWeight: 800, color: '#38bdf8' }}>
              {annualReturn}% p.a.
            </span>
          </div>
          <input
            type="range"
            min="6"
            max="22"
            step="0.5"
            value={annualReturn}
            onChange={e => setAnnualReturn(Number(e.target.value))}
            style={{ width: '100%', accentColor: '#38bdf8', cursor: 'pointer' }}
          />
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: 'var(--text-muted)', marginTop: '6px' }}>
            <span>6% (FD)</span>
            <span>12% (Nifty Index)</span>
            <span>18% (High Growth)</span>
          </div>
        </div>

        {/* Time Horizon Slider */}
        <div className="glass-panel" style={{ padding: '20px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <span style={{ fontSize: '13px', color: 'var(--text-secondary)', fontWeight: 600 }}>
              Time Horizon
            </span>
            <span className="font-mono" style={{ fontSize: '18px', fontWeight: 800, color: 'var(--accent-amber)' }}>
              {years} Years
            </span>
          </div>
          <input
            type="range"
            min="1"
            max="25"
            step="1"
            value={years}
            onChange={e => setYears(Number(e.target.value))}
            style={{ width: '100%', accentColor: 'var(--accent-amber)', cursor: 'pointer' }}
          />
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: 'var(--text-muted)', marginTop: '6px' }}>
            <span>1 Year</span>
            <span>10 Years</span>
            <span>25 Years</span>
          </div>
        </div>

      </div>

      {/* Corpus Projection Metric Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '16px' }}>
        
        <div className="glass-panel" style={{ padding: '22px' }}>
          <span style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-muted)', fontWeight: 700 }}>
            Total Capital Invested
          </span>
          <div className={`font-mono ${isPrivacyMasked ? 'privacy-masked' : ''}`} style={{ fontSize: '24px', fontWeight: 800, color: 'var(--text-primary)', marginTop: '4px' }}>
            {formatAmount(simulation.totalInvested, isPrivacyMasked)}
          </div>
        </div>

        <div className="glass-panel" style={{ padding: '22px' }}>
          <span style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-muted)', fontWeight: 700 }}>
            Estimated Wealth Created
          </span>
          <div className={`font-mono ${isPrivacyMasked ? 'privacy-masked' : ''}`} style={{ fontSize: '24px', fontWeight: 800, color: 'var(--accent-emerald-light)', marginTop: '4px' }}>
            {formatAmount(simulation.futureValue, isPrivacyMasked)}
          </div>
        </div>

        <div className="glass-panel" style={{ padding: '22px' }}>
          <span style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-muted)', fontWeight: 700 }}>
            Pure Compound Gain
          </span>
          <div className={`font-mono ${isPrivacyMasked ? 'privacy-masked' : ''}`} style={{ fontSize: '24px', fontWeight: 800, color: '#38bdf8', marginTop: '4px' }}>
            +{formatAmount(simulation.wealthGain, isPrivacyMasked)}
          </div>
        </div>

      </div>

      {/* Chart */}
      <div className="glass-panel" style={{ padding: '24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px' }}>
          <div>
            <h3 style={{ fontSize: '16px', fontWeight: 700 }}>Growth Trajectory (Invested vs Wealth)</h3>
            <p style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Visualizing compounding acceleration over {years} years</p>
          </div>
          <div style={{ display: 'flex', gap: '14px', fontSize: '12px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--text-secondary)' }}>
              <span style={{ width: '10px', height: '10px', borderRadius: '50%', background: 'var(--accent-emerald)' }} />
              <span>Total Wealth</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--text-secondary)' }}>
              <span style={{ width: '10px', height: '10px', borderRadius: '50%', background: 'rgba(255, 255, 255, 0.3)' }} />
              <span>Capital Invested</span>
            </div>
          </div>
        </div>

        <div style={{ height: '320px', width: '100%' }}>
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={simulation.chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="wealthGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                </linearGradient>
                <linearGradient id="investedGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#94a3b8" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#94a3b8" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="year" stroke="var(--text-muted)" fontSize={12} tickLine={false} />
              <YAxis stroke="var(--text-muted)" fontSize={12} tickLine={false} />
              <Tooltip
                formatter={(val: any) => [formatAmount(Number(val), isPrivacyMasked)]}
                contentStyle={{ background: '#0e131f', border: '1px solid var(--border-medium)', borderRadius: '8px', color: '#fff' }}
              />
              <Area type="monotone" dataKey="wealth" name="Total Wealth" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#wealthGrad)" />
              <Area type="monotone" dataKey="invested" name="Invested Capital" stroke="#94a3b8" strokeWidth={2} fillOpacity={1} fill="url(#investedGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

    </div>
  );
};
