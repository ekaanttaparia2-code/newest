import React, { useState } from 'react';
import type { CategoryBudgetStatus } from '../../hooks/useBudgets';
import type { Category } from '../../db/types';
import { usePrivacy } from '../../context/PrivacyContext';
import { useCurrency } from '../../context/CurrencyContext';
import { CategoryIcon } from '../ui/CategoryIcon';
import { AlertTriangle, CheckCircle2, Edit2, Calendar, X, Check } from 'lucide-react';

interface BudgetsViewProps {
  budgetStatuses: CategoryBudgetStatus[];
  allCategories?: Category[];
  onUpdateLimit: (categoryId: string, limit: number) => Promise<void>;
}

export const BudgetsView: React.FC<BudgetsViewProps> = ({
  budgetStatuses,
  onUpdateLimit
}) => {
  const { isPrivacyMasked } = usePrivacy();
  const { formatAmount } = useCurrency();
  const [editingCatId, setEditingCatId] = useState<string | null>(null);
  const [editLimitValue, setEditLimitValue] = useState<string>('');

  // Calculate days left in month
  const now = new Date();
  const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  const daysRemaining = Math.max(1, daysInMonth - now.getDate() + 1);

  const totalBudgeted = budgetStatuses.reduce((s, b) => s + b.limit, 0);
  const totalSpent = budgetStatuses.reduce((s, b) => s + b.spent, 0);
  const totalRemaining = Math.max(0, totalBudgeted - totalSpent);
  const safeDailySpend = totalRemaining / daysRemaining;

  const handleStartEdit = (catId: string, currentLimit: number) => {
    setEditingCatId(catId);
    setEditLimitValue(currentLimit.toString());
  };

  const handleSaveEdit = async (catId: string) => {
    const parsed = parseFloat(editLimitValue);
    if (!isNaN(parsed) && parsed >= 0) {
      await onUpdateLimit(catId, parsed);
    }
    setEditingCatId(null);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      
      {/* Header Banner */}
      <div className="glass-panel" style={{ padding: '24px', display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'center', gap: '16px' }}>
        <div>
          <h2 style={{ fontSize: '18px', fontWeight: 700, color: 'var(--text-primary)' }}>
            Monthly Category Budgets
          </h2>
          <p style={{ fontSize: '13px', color: 'var(--text-muted)' }}>
            Guardrails to keep your spending controlled and conscious
          </p>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', background: 'var(--bg-surface-elevated)', border: '1px solid var(--border-subtle)', padding: '8px 16px', borderRadius: 'var(--radius-md)' }}>
          <Calendar size={16} color="var(--accent-emerald)" />
          <span style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-secondary)' }}>
            {daysRemaining} Days Left in {now.toLocaleString('default', { month: 'long' })}
          </span>
        </div>
      </div>

      {/* Hero Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '16px' }}>
        
        <div className="glass-panel" style={{ padding: '18px 22px' }}>
          <span style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-muted)', fontWeight: 700 }}>
            Total Budgeted
          </span>
          <div className={`font-mono ${isPrivacyMasked ? 'privacy-masked' : ''}`} style={{ fontSize: '22px', fontWeight: 800, color: 'var(--text-primary)', marginTop: '4px' }}>
            {formatAmount(totalBudgeted, isPrivacyMasked)}
          </div>
        </div>

        <div className="glass-panel" style={{ padding: '18px 22px' }}>
          <span style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-muted)', fontWeight: 700 }}>
            Actual Spent
          </span>
          <div className={`font-mono ${isPrivacyMasked ? 'privacy-masked' : ''}`} style={{ fontSize: '22px', fontWeight: 800, color: 'var(--accent-rose-light)', marginTop: '4px' }}>
            {formatAmount(totalSpent, isPrivacyMasked)}
          </div>
        </div>

        <div className="glass-panel" style={{ padding: '18px 22px' }}>
          <span style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-muted)', fontWeight: 700 }}>
            Remaining Cap
          </span>
          <div className={`font-mono ${isPrivacyMasked ? 'privacy-masked' : ''}`} style={{ fontSize: '22px', fontWeight: 800, color: 'var(--accent-emerald-light)', marginTop: '4px' }}>
            {formatAmount(totalRemaining, isPrivacyMasked)}
          </div>
        </div>

        <div className="glass-panel" style={{ padding: '18px 22px' }}>
          <span style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-muted)', fontWeight: 700 }}>
            Safe Daily Spend
          </span>
          <div className={`font-mono ${isPrivacyMasked ? 'privacy-masked' : ''}`} style={{ fontSize: '22px', fontWeight: 800, color: '#38bdf8', marginTop: '4px' }}>
            {formatAmount(safeDailySpend, isPrivacyMasked)}/day
          </div>
        </div>

      </div>

      {/* Budget Cards List */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '16px' }}>
        {budgetStatuses.map(status => {
          const isOver = status.isOverBudget;
          const isNear = status.isNearLimit;
          const progressPercent = Math.min(100, Math.round(status.percentage));
          const isEditing = editingCatId === status.category.id;

          return (
            <div
              key={status.category.id}
              className="glass-panel interactive-card"
              style={{ padding: '20px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}
            >
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <div
                      style={{
                        width: '36px',
                        height: '36px',
                        borderRadius: '10px',
                        background: 'rgba(255, 255, 255, 0.06)',
                        color: status.category.color,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                      }}
                    >
                      <CategoryIcon iconName={status.category.icon} size={18} />
                    </div>
                    <div>
                      <h4 style={{ fontSize: '15px', fontWeight: 600, color: 'var(--text-primary)' }}>
                        {status.category.name}
                      </h4>
                      <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>
                        {status.remaining > 0 ? `${formatAmount(status.remaining, isPrivacyMasked)} remaining` : 'Limit reached'}
                      </span>
                    </div>
                  </div>

                  {/* Status indicator */}
                  {isOver ? (
                    <span className="badge-expense" style={{ fontSize: '11px' }}>
                      <AlertTriangle size={11} /> Over Budget
                    </span>
                  ) : isNear ? (
                    <span style={{ background: 'rgba(245, 158, 11, 0.15)', color: 'var(--accent-amber)', fontSize: '11px', padding: '3px 8px', borderRadius: '999px', fontWeight: 600 }}>
                      80%+ Used
                    </span>
                  ) : (
                    <span className="badge-income" style={{ fontSize: '11px' }}>
                      <CheckCircle2 size={11} /> Healthy
                    </span>
                  )}
                </div>

                {/* Numbers */}
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '10px' }}>
                  <div>
                    <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Spent</span>
                    <div className={`font-mono ${isPrivacyMasked ? 'privacy-masked' : ''}`} style={{ fontSize: '17px', fontWeight: 700, color: isOver ? 'var(--accent-rose-light)' : 'var(--text-primary)' }}>
                      {formatAmount(status.spent, isPrivacyMasked)}
                    </div>
                  </div>

                  <div style={{ textAlign: 'right' }}>
                    <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Limit</span>
                    {isEditing ? (
                      <div style={{ display: 'flex', alignItems: 'center', gap: '4px', marginTop: '2px' }}>
                        <input
                          type="number"
                          className="form-input font-mono"
                          value={editLimitValue}
                          onChange={e => setEditLimitValue(e.target.value)}
                          style={{ width: '80px', padding: '4px 8px', fontSize: '13px' }}
                          autoFocus
                        />
                        <button className="btn-icon" style={{ width: '28px', height: '28px' }} onClick={() => handleSaveEdit(status.category.id)}>
                          <Check size={13} color="var(--accent-emerald)" />
                        </button>
                        <button className="btn-icon" style={{ width: '28px', height: '28px' }} onClick={() => setEditingCatId(null)}>
                          <X size={13} />
                        </button>
                      </div>
                    ) : (
                      <div
                        onClick={() => handleStartEdit(status.category.id, status.limit)}
                        className={`font-mono ${isPrivacyMasked ? 'privacy-masked' : ''}`}
                        style={{ fontSize: '15px', fontWeight: 600, color: 'var(--text-secondary)', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px' }}
                        title="Click to edit budget limit"
                      >
                        {formatAmount(status.limit, isPrivacyMasked)}
                        <Edit2 size={12} color="var(--text-muted)" />
                      </div>
                    )}
                  </div>
                </div>

                {/* Progress bar */}
                <div style={{ width: '100%', height: '8px', background: 'rgba(255, 255, 255, 0.06)', borderRadius: '999px', overflow: 'hidden' }}>
                  <div
                    style={{
                      width: `${progressPercent}%`,
                      height: '100%',
                      background: isOver ? 'var(--accent-rose)' : isNear ? 'var(--accent-amber)' : 'var(--accent-emerald)',
                      borderRadius: '999px',
                      transition: 'width 0.4s ease'
                    }}
                  />
                </div>
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '12px', fontSize: '12px', color: 'var(--text-muted)' }}>
                <span>{progressPercent}% consumed</span>
                <span>{formatAmount(status.limit - status.spent, isPrivacyMasked)} left</span>
              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
};
