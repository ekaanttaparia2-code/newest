import React from 'react';
import { LayoutDashboard, Receipt, Mic, Landmark, Target } from 'lucide-react';
import type { NavTab } from './Sidebar';
import { soundFx } from '../../lib/soundFx';

interface BottomNavProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onOpenVoiceModal: () => void;
  isMobileFrame?: boolean;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onSelectTab,
  onOpenVoiceModal,
  isMobileFrame = false
}) => {
  return (
    <nav
      className="mobile-only-nav"
      style={{
        position: isMobileFrame ? 'absolute' : 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        width: '100%',
        height: '64px',
        background: 'rgba(12, 16, 28, 0.95)',
        backdropFilter: 'blur(20px)',
        WebkitBackdropFilter: 'blur(20px)',
        borderTop: '1px solid var(--border-subtle)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-around',
        zIndex: 100,
        paddingBottom: isMobileFrame ? '8px' : 'env(safe-area-inset-bottom, 4px)',
        boxSizing: 'border-box'
      }}
    >
      {/* Dashboard */}
      <button
        onClick={() => {
          soundFx.playPop();
          onSelectTab('dashboard');
        }}
        style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '3px',
          color: currentTab === 'dashboard' ? 'var(--accent-emerald)' : 'var(--text-muted)',
          fontSize: '11px',
          fontWeight: 600,
          background: 'transparent',
          border: 'none',
          padding: '4px 8px'
        }}
      >
        <LayoutDashboard size={18} />
        <span>Home</span>
      </button>

      {/* Transactions */}
      <button
        onClick={() => {
          soundFx.playPop();
          onSelectTab('transactions');
        }}
        style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '3px',
          color: currentTab === 'transactions' ? 'var(--accent-emerald)' : 'var(--text-muted)',
          fontSize: '11px',
          fontWeight: 600,
          background: 'transparent',
          border: 'none',
          padding: '4px 8px'
        }}
      >
        <Receipt size={18} />
        <span>Activity</span>
      </button>

      {/* Center Voice Mic Floating Action Button */}
      <button
        onClick={() => {
          soundFx.playPop();
          onOpenVoiceModal();
        }}
        title="Voice Log"
        style={{
          marginTop: '-22px',
          width: '52px',
          height: '52px',
          borderRadius: '50%',
          background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
          color: '#ffffff',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: '0 4px 18px rgba(16, 185, 129, 0.45)',
          border: '3px solid #080b11',
          cursor: 'pointer',
          flexShrink: 0
        }}
      >
        <Mic size={22} />
      </button>

      {/* Goals */}
      <button
        onClick={() => {
          soundFx.playPop();
          onSelectTab('goals');
        }}
        style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '3px',
          color: currentTab === 'goals' ? 'var(--accent-emerald)' : 'var(--text-muted)',
          fontSize: '11px',
          fontWeight: 600,
          background: 'transparent',
          border: 'none',
          padding: '4px 8px'
        }}
      >
        <Target size={18} />
        <span>Goals</span>
      </button>

      {/* Accounts */}
      <button
        onClick={() => {
          soundFx.playPop();
          onSelectTab('accounts');
        }}
        style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '3px',
          color: currentTab === 'accounts' ? 'var(--accent-emerald)' : 'var(--text-muted)',
          fontSize: '11px',
          fontWeight: 600,
          background: 'transparent',
          border: 'none',
          padding: '4px 8px'
        }}
      >
        <Landmark size={18} />
        <span>Accounts</span>
      </button>
    </nav>
  );
};
