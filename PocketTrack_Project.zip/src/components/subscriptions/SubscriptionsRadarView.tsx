import React, { useState } from 'react';
import { Calendar, Plus, Check, X, ShieldAlert, Zap, Film, Music, Dumbbell, Wifi } from 'lucide-react';
import { useCurrency } from '../../context/CurrencyContext';
import { usePrivacy } from '../../context/PrivacyContext';

interface SubItem {
  id: string;
  name: string;
  amount: number;
  frequency: 'monthly' | 'yearly';
  billingDay: number; // day of month
  category: string;
  color: string;
  icon: string;
  isActive: boolean;
}

export const SubscriptionsRadarView: React.FC = () => {
  const { symbol, formatAmount } = useCurrency();
  const { isPrivacyMasked } = usePrivacy();

  const [subscriptions, setSubscriptions] = useState<SubItem[]>(() => {
    const saved = localStorage.getItem('pockettrack_subscriptions');
    if (saved) {
      try { return JSON.parse(saved); } catch { /* ignore */ }
    }
    return [
      { id: 'sub-1', name: 'Netflix Premium 4K', amount: 649, frequency: 'monthly', billingDay: 4, category: 'OTT', color: '#f43f5e', icon: 'Film', isActive: true },
      { id: 'sub-2', name: 'JioFiber 300Mbps', amount: 999, frequency: 'monthly', billingDay: 12, category: 'Wifi', color: '#06b6d4', icon: 'Wifi', isActive: true },
      { id: 'sub-3', name: 'Spotify Duo Family', amount: 149, frequency: 'monthly', billingDay: 18, category: 'Music', color: '#10b981', icon: 'Music', isActive: true },
      { id: 'sub-4', name: 'Cult.fit Gym & Pass', amount: 1750, frequency: 'monthly', billingDay: 24, category: 'Fitness', color: '#f59e0b', icon: 'Dumbbell', isActive: true },
      { id: 'sub-5', name: 'Amazon Prime Annual', amount: 1499, frequency: 'yearly', billingDay: 28, category: 'Shopping', color: '#38bdf8', icon: 'Zap', isActive: true },
    ];
  });

  const [isAddOpen, setIsAddOpen] = useState<boolean>(false);
  const [subName, setSubName] = useState<string>('');
  const [subAmount, setSubAmount] = useState<string>('');
  const [subDay, setSubDay] = useState<string>('5');
  const [subFreq, setSubFreq] = useState<'monthly' | 'yearly'>('monthly');

  const now = new Date();
  const todayDate = now.getDate();

  const getDaysUntilDue = (day: number) => {
    if (day >= todayDate) {
      return day - todayDate;
    }
    const daysInCurrentMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
    return daysInCurrentMonth - todayDate + day;
  };

  const monthlyBurn = subscriptions
    .filter(s => s.isActive)
    .reduce((sum, s) => sum + (s.frequency === 'yearly' ? s.amount / 12 : s.amount), 0);

  const yearlyBurn = monthlyBurn * 12;

  const toggleActive = (id: string) => {
    const updated = subscriptions.map(s => s.id === id ? { ...s, isActive: !s.isActive } : s);
    setSubscriptions(updated);
    localStorage.setItem('pockettrack_subscriptions', JSON.stringify(updated));
  };

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(subAmount);
    if (!subName.trim() || isNaN(amount) || amount <= 0) return;

    const newSub: SubItem = {
      id: `sub-${Date.now()}`,
      name: subName.trim(),
      amount,
      frequency: subFreq,
      billingDay: parseInt(subDay, 10) || 1,
      category: 'Subscription',
      color: '#38bdf8',
      icon: 'Zap',
      isActive: true
    };

    const updated = [...subscriptions, newSub];
    setSubscriptions(updated);
    localStorage.setItem('pockettrack_subscriptions', JSON.stringify(updated));
    setSubName('');
    setSubAmount('');
    setIsAddOpen(false);
  };

  const renderIcon = (icon: string) => {
    switch (icon) {
      case 'Film': return <Film size={18} />;
      case 'Music': return <Music size={18} />;
      case 'Dumbbell': return <Dumbbell size={18} />;
      case 'Wifi': return <Wifi size={18} />;
      default: return <Zap size={18} />;
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      
      {/* Header */}
      <div className="glass-panel" style={{ padding: '24px', display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'center', gap: '16px' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div style={{ width: '36px', height: '36px', borderRadius: '10px', background: 'rgba(6, 182, 212, 0.15)', color: '#06b6d4', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Calendar size={20} />
            </div>
            <div>
              <h2 style={{ fontSize: '18px', fontWeight: 700, color: 'var(--text-primary)' }}>
                Recurring Subscriptions & Bills Radar
              </h2>
              <p style={{ fontSize: '13px', color: 'var(--text-muted)' }}>
                Audit monthly recurring burn rate and prevent unwanted renewals
              </p>
            </div>
          </div>
        </div>

        <button className="btn-primary" onClick={() => setIsAddOpen(true)}>
          <Plus size={16} />
          <span>Add Subscription</span>
        </button>
      </div>

      {/* Burn Rate Metrics */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '16px' }}>
        
        <div className="glass-panel" style={{ padding: '22px' }}>
          <span style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-muted)', fontWeight: 700 }}>
            Monthly Fixed Burn Rate
          </span>
          <div className={`font-mono ${isPrivacyMasked ? 'privacy-masked' : ''}`} style={{ fontSize: '24px', fontWeight: 800, color: 'var(--accent-rose-light)', marginTop: '4px' }}>
            {formatAmount(Math.round(monthlyBurn), isPrivacyMasked)}/mo
          </div>
          <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
            Annualized: {formatAmount(Math.round(yearlyBurn), isPrivacyMasked)}/year
          </span>
        </div>

        <div className="glass-panel" style={{ padding: '22px' }}>
          <span style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-muted)', fontWeight: 700 }}>
            Active Services Tracked
          </span>
          <div className="font-mono" style={{ fontSize: '24px', fontWeight: 800, color: 'var(--text-primary)', marginTop: '4px' }}>
            {subscriptions.filter(s => s.isActive).length} Subscriptions
          </div>
          <span style={{ fontSize: '12px', color: 'var(--accent-emerald-light)' }}>
            All renewals accounted for
          </span>
        </div>

        <div className="glass-panel" style={{ padding: '22px', background: 'rgba(245, 158, 11, 0.06)', borderColor: 'rgba(245, 158, 11, 0.2)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--accent-amber)', fontSize: '12px', fontWeight: 700 }}>
            <ShieldAlert size={15} />
            <span>Optimization Tip</span>
          </div>
          <p style={{ fontSize: '12px', color: 'var(--text-secondary)', marginTop: '6px', lineHeight: 1.4 }}>
            Unsubscribing from 1 unused OTT service saves you ~{symbol}6,000 every year towards your wealth goals!
          </p>
        </div>

      </div>

      {/* Subscriptions List */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '16px' }}>
        {subscriptions.map(sub => {
          const daysDue = getDaysUntilDue(sub.billingDay);
          const isDueSoon = daysDue <= 5 && sub.isActive;

          return (
            <div
              key={sub.id}
              className="glass-panel interactive-card"
              style={{
                padding: '20px',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                opacity: sub.isActive ? 1 : 0.6
              }}
            >
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '14px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div
                      style={{
                        width: '40px',
                        height: '40px',
                        borderRadius: '10px',
                        background: `${sub.color}22`,
                        color: sub.color,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                      }}
                    >
                      {renderIcon(sub.icon)}
                    </div>
                    <div>
                      <h4 style={{ fontSize: '15px', fontWeight: 700, color: 'var(--text-primary)' }}>{sub.name}</h4>
                      <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>
                        Renews on day {sub.billingDay} of month
                      </span>
                    </div>
                  </div>

                  <span
                    style={{
                      fontSize: '11px',
                      padding: '3px 8px',
                      borderRadius: '4px',
                      background: isDueSoon ? 'rgba(244, 63, 94, 0.15)' : 'rgba(255, 255, 255, 0.05)',
                      color: isDueSoon ? 'var(--accent-rose-light)' : 'var(--text-secondary)',
                      fontWeight: 600
                    }}
                  >
                    {daysDue === 0 ? 'Due Today!' : `Renews in ${daysDue}d`}
                  </span>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginTop: '14px', paddingTop: '12px', borderTop: '1px solid var(--border-subtle)' }}>
                  <div>
                    <span style={{ fontSize: '11px', color: 'var(--text-muted)', display: 'block' }}>Cost</span>
                    <span className={`font-mono ${isPrivacyMasked ? 'privacy-masked' : ''}`} style={{ fontSize: '18px', fontWeight: 800, color: 'var(--text-primary)' }}>
                      {formatAmount(sub.amount, isPrivacyMasked)}
                      <span style={{ fontSize: '12px', color: 'var(--text-muted)', fontWeight: 500 }}>
                        /{sub.frequency === 'yearly' ? 'yr' : 'mo'}
                      </span>
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => toggleActive(sub.id)}
                    className="btn-secondary"
                    style={{ fontSize: '11px', padding: '5px 10px' }}
                  >
                    {sub.isActive ? 'Active · Pause' : 'Paused · Resume'}
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Subscription Modal */}
      {isAddOpen && (
        <div className="modal-overlay" onClick={() => setIsAddOpen(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '18px 24px', borderBottom: '1px solid var(--border-subtle)' }}>
              <h3 style={{ fontSize: '17px', fontWeight: 600 }}>Track New Subscription</h3>
              <button className="btn-icon" onClick={() => setIsAddOpen(false)}>
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleAdd} style={{ padding: '20px 24px' }}>
              <div style={{ marginBottom: '14px' }}>
                <label className="form-label">Service Name</label>
                <input
                  type="text"
                  className="form-input"
                  placeholder="e.g. Disney+ Hotstar, AWS, Gym"
                  value={subName}
                  onChange={e => setSubName(e.target.value)}
                  required
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '14px' }}>
                <div>
                  <label className="form-label">Cost ({symbol})</label>
                  <input
                    type="number"
                    step="0.01"
                    className="form-input font-mono"
                    placeholder="499"
                    value={subAmount}
                    onChange={e => setSubAmount(e.target.value)}
                    required
                  />
                </div>
                <div>
                  <label className="form-label">Frequency</label>
                  <select className="form-select" value={subFreq} onChange={e => setSubFreq(e.target.value as any)}>
                    <option value="monthly">Monthly</option>
                    <option value="yearly">Yearly</option>
                  </select>
                </div>
              </div>

              <div style={{ marginBottom: '24px' }}>
                <label className="form-label">Billing Day of Month (1 - 31)</label>
                <input
                  type="number"
                  min="1"
                  max="31"
                  className="form-input font-mono"
                  value={subDay}
                  onChange={e => setSubDay(e.target.value)}
                  required
                />
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '12px' }}>
                <button type="button" className="btn-secondary" onClick={() => setIsAddOpen(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn-primary">
                  <Check size={16} />
                  Add Subscription
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
