import React, { useState } from 'react';
import { X, Check, ArrowRightLeft } from 'lucide-react';
import type { Account } from '../../db/types';
import confetti from 'canvas-confetti';

interface TransferModalProps {
  isOpen: boolean;
  onClose: () => void;
  accounts: Account[];
  onTransfer: (data: {
    fromAccountId: string;
    toAccountId: string;
    amount: number;
    notes?: string;
  }) => Promise<any>;
}

export const TransferModal: React.FC<TransferModalProps> = ({
  isOpen,
  onClose,
  accounts,
  onTransfer
}) => {
  const [fromAccountId, setFromAccountId] = useState<string>(accounts[0]?.id || '');
  const [toAccountId, setToAccountId] = useState<string>(accounts[1]?.id || '');
  const [amount, setAmount] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      alert('Please enter a valid transfer amount');
      return;
    }

    if (fromAccountId === toAccountId) {
      alert('From and To accounts must be different');
      return;
    }

    setIsSubmitting(true);
    try {
      await onTransfer({
        fromAccountId,
        toAccountId,
        amount: parsedAmount,
        notes: notes.trim() || 'Internal Account Transfer'
      });

      confetti({
        particleCount: 30,
        spread: 50,
        origin: { y: 0.7 }
      });

      onClose();
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '460px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '18px 24px', borderBottom: '1px solid var(--border-subtle)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div style={{ width: '32px', height: '32px', borderRadius: '8px', background: 'rgba(99, 102, 241, 0.15)', color: '#818cf8', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <ArrowRightLeft size={16} />
            </div>
            <h3 style={{ fontSize: '17px', fontWeight: 600 }}>Transfer Funds</h3>
          </div>
          <button className="btn-icon" onClick={onClose}>
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} style={{ padding: '20px 24px' }}>
          
          <div style={{ marginBottom: '16px' }}>
            <label className="form-label">Transfer Amount ($)</label>
            <input
              type="number"
              step="0.01"
              autoFocus
              placeholder="0.00"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              className="form-input font-mono"
              style={{ fontSize: '24px', fontWeight: 700 }}
              required
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '16px' }}>
            <div>
              <label className="form-label">From Account</label>
              <select
                className="form-select"
                value={fromAccountId}
                onChange={e => setFromAccountId(e.target.value)}
                required
              >
                {accounts.map(acc => (
                  <option key={acc.id} value={acc.id}>
                    {acc.name} (${acc.balance.toFixed(2)})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="form-label">To Account</label>
              <select
                className="form-select"
                value={toAccountId}
                onChange={e => setToAccountId(e.target.value)}
                required
              >
                {accounts.map(acc => (
                  <option key={acc.id} value={acc.id}>
                    {acc.name} (${acc.balance.toFixed(2)})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div style={{ marginBottom: '22px' }}>
            <label className="form-label">Note (Optional)</label>
            <input
              type="text"
              className="form-input"
              placeholder="e.g., Credit Card Payment or Savings Deposit"
              value={notes}
              onChange={e => setNotes(e.target.value)}
            />
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '12px' }}>
            <button type="button" className="btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn-primary" disabled={isSubmitting || !amount}>
              <Check size={16} />
              Execute Transfer
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
