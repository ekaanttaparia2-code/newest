import React from 'react';
import { Zap, ArrowRight, TrendingUp, Globe, Sparkles, Lock } from 'lucide-react';
import { useLanguage, type LanguageCode } from '../../context/LanguageContext';
import { soundFx } from '../../lib/soundFx';

interface WelcomeExplainerProps {
  onContinueToAuth: () => void;
  onQuickStartGuest: () => void;
}

export const WelcomeExplainer: React.FC<WelcomeExplainerProps> = ({
  onContinueToAuth,
  onQuickStartGuest
}) => {
  const { language, setLanguage } = useLanguage();

  const handleStart = () => {
    soundFx.playLevelUp();
    onContinueToAuth();
  };

  const handleGuest = () => {
    soundFx.playCashChime();
    onQuickStartGuest();
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        width: '100vw',
        background: 'radial-gradient(circle at 50% 20%, #151d30 0%, #080b11 80%)',
        color: 'var(--text-primary)',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '32px 20px',
        position: 'relative',
        overflowX: 'hidden'
      }}
    >
      {/* Top Language Switcher Bar */}
      <div
        style={{
          position: 'absolute',
          top: '20px',
          right: '24px',
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          background: 'rgba(255, 255, 255, 0.06)',
          border: '1px solid var(--border-subtle)',
          borderRadius: '999px',
          padding: '4px 12px'
        }}
      >
        <Globe size={14} color="var(--accent-emerald)" />
        {(['en', 'hi', 'hinglish'] as LanguageCode[]).map(lang => (
          <button
            key={lang}
            type="button"
            onClick={() => {
              soundFx.playPop();
              setLanguage(lang);
            }}
            style={{
              padding: '4px 8px',
              borderRadius: '999px',
              fontSize: '12px',
              fontWeight: 600,
              color: language === lang ? '#ffffff' : 'var(--text-muted)',
              background: language === lang ? 'rgba(16, 185, 129, 0.25)' : 'transparent',
              transition: 'all 0.15s ease'
            }}
          >
            {lang === 'en' ? 'English' : lang === 'hi' ? 'हिन्दी' : 'Hinglish'}
          </button>
        ))}
      </div>

      <div style={{ maxWidth: '840px', width: '100%', textAlign: 'center' }}>
        
        {/* Brand Icon */}
        <div
          style={{
            width: '64px',
            height: '64px',
            borderRadius: '18px',
            background: 'linear-gradient(135deg, #10b981 0%, #064e3b 100%)',
            color: '#fff',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 20px auto',
            boxShadow: '0 0 35px -5px rgba(16, 185, 129, 0.5)'
          }}
        >
          <Sparkles size={32} />
        </div>

        {/* Hero Title */}
        <h1
          style={{
            fontSize: 'clamp(28px, 5vw, 44px)',
            fontWeight: 800,
            lineHeight: 1.15,
            letterSpacing: '-0.03em',
            marginBottom: '16px',
            background: 'linear-gradient(180deg, #ffffff 0%, #94a3b8 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent'
          }}
        >
          {language === 'hi' 
            ? 'आपका अपना निजी वेल्थ और खर्च ट्रैकर' 
            : language === 'hinglish' 
            ? 'PocketTrack: Aapka Private Paisa & Kharcha OS' 
            : 'PocketTrack: Your Private Financial OS'}
        </h1>

        <p
          style={{
            fontSize: 'clamp(15px, 2vw, 18px)',
            color: 'var(--text-secondary)',
            maxWidth: '620px',
            margin: '0 auto 36px auto',
            lineHeight: 1.6
          }}
        >
          {language === 'hi'
            ? 'कोई विज्ञापन नहीं, कोई डेटा ट्रैकिंग नहीं। पूरी तरह से आपके डिवाइस पर सुरक्षित, बोलकर खर्च लिखें और अपनी कुल संपत्ति को बढ़ते देखें।'
            : language === 'hinglish'
            ? 'Zero ads, zero data sharing. Pura data aapke device par offline secure rehta hai. 1-tap mein Chai ya Swiggy log karein.'
            : 'Zero ads, zero bank scrapers, 100% offline-first. Log daily expenses in 1 second, track multiple accounts, and master your cash flow.'}
        </p>

        {/* 3 Core Pillars Cards */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
            gap: '16px',
            marginBottom: '40px',
            textAlign: 'left'
          }}
        >
          <div className="glass-panel" style={{ padding: '22px' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '10px', background: 'rgba(16, 185, 129, 0.15)', color: 'var(--accent-emerald)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '14px' }}>
              <Lock size={20} />
            </div>
            <h4 style={{ fontSize: '16px', fontWeight: 700, marginBottom: '6px' }}>
              {language === 'hi' ? '100% निजी और ऑफलाइन' : language === 'hinglish' ? '100% Private & Offline' : '100% Private & Offline'}
            </h4>
            <p style={{ fontSize: '13px', color: 'var(--text-muted)', lineHeight: 1.5 }}>
              {language === 'hi'
                ? 'आपका पैसा और खाते सीधे आपके डिवाइस पर रहते हैं। बिना इंटरनेट के भी हर फीचर काम करता है।'
                : language === 'hinglish'
                ? 'Aapke accounts aur kharche sirf aapke phone/PC par hain. Kisi third-party server par data leak ka risk nahi.'
                : 'Your financial data is stored locally in your browser/device database. Works seamlessly without an internet connection.'}
            </p>
          </div>

          <div className="glass-panel" style={{ padding: '22px' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '10px', background: 'rgba(245, 158, 11, 0.15)', color: 'var(--accent-amber)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '14px' }}>
              <Zap size={20} />
            </div>
            <h4 style={{ fontSize: '16px', fontWeight: 700, marginBottom: '6px' }}>
              {language === 'hi' ? '1-टैप और वॉइस लॉगिंग' : language === 'hinglish' ? '1-Tap & Voice Logging' : '1-Tap & Voice Logging'}
            </h4>
            <p style={{ fontSize: '13px', color: 'var(--text-muted)', lineHeight: 1.5 }}>
              {language === 'hi'
                ? 'चाय, ऑटो या स्विगी खर्च को 1 क्लिक में दर्ज करें। या सीधे बोलें "चाय ₹20 कैश से"।'
                : language === 'hinglish'
                ? 'Chai ₹20 ya Auto fare bina type kiye 1 tap mein add karein, ya bolkar likhein.'
                : 'Log everyday expenses like Coffee or Commute with a single click, or speak naturally in your everyday language.'}
            </p>
          </div>

          <div className="glass-panel" style={{ padding: '22px' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '10px', background: 'rgba(56, 189, 248, 0.15)', color: '#38bdf8', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '14px' }}>
              <TrendingUp size={20} />
            </div>
            <h4 style={{ fontSize: '16px', fontWeight: 700, marginBottom: '6px' }}>
              {language === 'hi' ? 'ऑटोमैटिक जोड़ और घटाव' : language === 'hinglish' ? 'Auto Balance Math' : 'Automatic Balance Math'}
            </h4>
            <p style={{ fontSize: '13px', color: 'var(--text-muted)', lineHeight: 1.5 }}>
              {language === 'hi'
                ? 'आय जोड़ते ही बैलेंस बढ़ता है, खर्च करते ही बैलेंस घटता है। सब कुछ वास्तविक समय में!'
                : language === 'hinglish'
                ? 'Kamai add karne par balance badhega, kharcha karne par apne aap ghatega. Zero confusion.'
                : 'Whenever you record income, balances increase. Whenever you spend, balances decrease automatically.'}
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '14px' }}>
          <button
            type="button"
            onClick={handleStart}
            className="btn-primary"
            style={{
              padding: '14px 32px',
              fontSize: '16px',
              borderRadius: 'var(--radius-lg)',
              width: '100%',
              maxWidth: '360px',
              boxShadow: '0 8px 30px rgba(16, 185, 129, 0.4)'
            }}
          >
            <span>
              {language === 'hi' ? 'शुरू करें और लॉगिन करें' : language === 'hinglish' ? 'Get Started & Setup Vault' : 'Get Started & Set Up Vault'}
            </span>
            <ArrowRight size={18} />
          </button>

          <button
            type="button"
            onClick={handleGuest}
            style={{
              background: 'transparent',
              border: 'none',
              color: 'var(--text-secondary)',
              fontSize: '14px',
              cursor: 'pointer',
              textDecoration: 'underline'
            }}
          >
            {language === 'hi' 
              ? 'बिना साइन-अप तुरंत शुरू करें (गेस्ट मोड)' 
              : language === 'hinglish' 
              ? 'Bina signup direct shuru karein (Guest Vault)' 
              : 'Jump straight into Guest Mode (No signup required)'}
          </button>
        </div>

      </div>
    </div>
  );
};
