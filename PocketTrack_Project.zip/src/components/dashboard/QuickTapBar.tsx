import React, { useState } from 'react';
import { Zap, Check } from 'lucide-react';
import { useCurrency } from '../../context/CurrencyContext';
import { soundFx } from '../../lib/soundFx';
import confetti from 'canvas-confetti';

interface QuickTapBarProps {
  onQuickLog: (data: {
    amount: number;
    notes: string;
    categoryId: string;
    accountId: string;
  }) => Promise<any>;
}

export const QuickTapBar: React.FC<QuickTapBarProps> = ({ onQuickLog }) => {
  const { symbol } = useCurrency();
  const [activeToast, setActiveToast] = useState<string | null>(null);

  const quickItems = [
    { label: 'Chai & Snacks', emoji: '☕', amount: 20, categoryId: 'cat-food', accountId: 'acc-cash' },
    { label: 'Auto / Metro', emoji: '🛺', amount: 80, categoryId: 'cat-transport', accountId: 'acc-cash' },
    { label: 'Swiggy / Meal', emoji: '🍔', amount: 350, categoryId: 'cat-food', accountId: 'acc-checking' },
    { label: 'Kirana / Blinkit', emoji: '🛒', amount: 850, categoryId: 'cat-groceries', accountId: 'acc-credit' },
    { label: 'Petrol Refill', emoji: '⛽', amount: 500, categoryId: 'cat-transport', accountId: 'acc-checking' },
    { label: 'Movie Ticket', emoji: '🍿', amount: 350, categoryId: 'cat-entertainment', accountId: 'acc-credit' },
  ];

  const handleTap = async (item: typeof quickItems[0]) => {
    soundFx.playCashChime();
    confetti({
      particleCount: 25,
      spread: 45,
      origin: { y: 0.8 },
      colors: ['#10b981', '#f59e0b', '#3b82f6']
    });

    await onQuickLog({
      amount: item.amount,
      notes: `${item.emoji} ${item.label}`,
      categoryId: item.categoryId,
      accountId: item.accountId
    });

    setActiveToast(`Logged ${symbol}${item.amount} for ${item.label}!`);
    setTimeout(() => setActiveToast(null), 2500);
  };

  return (
    <div
      className="glass-panel"
      style={{
        padding: '16px 20px',
        marginBottom: '20px',
        background: 'linear-gradient(90deg, rgba(16, 185, 129, 0.08) 0%, rgba(14, 19, 31, 0.9) 100%)',
        borderColor: 'rgba(16, 185, 129, 0.25)',
        position: 'relative',
        overflow: 'hidden'
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <div style={{ width: '24px', height: '24px', borderRadius: '6px', background: 'rgba(16, 185, 129, 0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--accent-emerald)' }}>
            <Zap size={14} />
          </div>
          <span style={{ fontSize: '13px', fontWeight: 700, color: 'var(--text-primary)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
            Instant 1-Tap Log Bar
          </span>
          <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>
            (Zero-friction quick tap)
          </span>
        </div>

        {activeToast && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px', color: 'var(--accent-emerald-light)', fontWeight: 600, background: 'rgba(16, 185, 129, 0.15)', padding: '3px 10px', borderRadius: '999px' }}>
            <Check size={13} />
            {activeToast}
          </div>
        )}
      </div>

      {/* Horizontal Scrollable Quick Chips */}
      <div style={{ display: 'flex', gap: '10px', overflowX: 'auto', paddingBottom: '4px' }}>
        {quickItems.map((item, idx) => (
          <button
            key={idx}
            type="button"
            onClick={() => handleTap(item)}
            className="interactive-card"
            style={{
              flexShrink: 0,
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              padding: '8px 14px',
              background: 'var(--bg-surface-elevated)',
              border: '1px solid var(--border-medium)',
              borderRadius: 'var(--radius-md)',
              color: 'var(--text-primary)',
              fontSize: '13px',
              fontWeight: 600,
              cursor: 'pointer'
            }}
          >
            <span style={{ fontSize: '16px' }}>{item.emoji}</span>
            <span>{item.label}</span>
            <span
              className="font-mono"
              style={{
                color: 'var(--accent-emerald-light)',
                background: 'rgba(16, 185, 129, 0.12)',
                padding: '2px 6px',
                borderRadius: '4px',
                fontSize: '12px'
              }}
            >
              {symbol}{item.amount}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
};
