import React from 'react';
import { ArrowUpRight, ArrowDownRight, TrendingUp, Plus, Mic } from 'lucide-react';
import { usePrivacy } from '../../context/PrivacyContext';
import { useCurrency } from '../../context/CurrencyContext';

interface NetWorthHeroProps {
  netWorth: number;
  totalAssets: number;
  totalLiabilities: number;
  monthlyIncome: number;
  monthlyExpense: number;
  onOpenVoiceModal: () => void;
  onOpenTransactionModal: () => void;
}

export const NetWorthHero: React.FC<NetWorthHeroProps> = ({
  netWorth,
  totalAssets,
  totalLiabilities,
  monthlyIncome,
  monthlyExpense,
  onOpenVoiceModal,
  onOpenTransactionModal
}) => {
  const { isPrivacyMasked } = usePrivacy();
  const { formatAmount } = useCurrency();
  const netCashFlow = monthlyIncome - monthlyExpense;
  const savingsRate = monthlyIncome > 0 ? Math.max(0, Math.round((netCashFlow / monthlyIncome) * 100)) : 0;

  return (
    <div
      className="glass-panel"
      style={{
        padding: '30px 32px',
        position: 'relative',
        overflow: 'hidden',
        background: 'linear-gradient(135deg, rgba(14, 19, 31, 0.95) 0%, rgba(20, 27, 43, 0.85) 100%)',
        marginBottom: '24px'
      }}
    >
      {/* Subtle background ambient mesh */}
      <div
        style={{
          position: 'absolute',
          top: '-40px',
          right: '-40px',
          width: '260px',
          height: '260px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(16, 185, 129, 0.12) 0%, transparent 70%)',
          pointerEvents: 'none'
        }}
      />

      <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'flex-start', gap: '20px' }}>
        
        {/* Left: Net Worth Big Numbers */}
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
            <span style={{ fontSize: '12px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--text-secondary)' }}>
              Total Net Worth
            </span>
            <div
              style={{
                background: 'rgba(16, 185, 129, 0.12)',
                color: 'var(--accent-emerald-light)',
                fontSize: '11px',
                fontWeight: 700,
                padding: '2px 8px',
                borderRadius: '6px',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '3px'
              }}
            >
              <TrendingUp size={12} />
              <span>Active</span>
            </div>
          </div>

          <div
            className={`font-mono ${isPrivacyMasked ? 'privacy-masked' : ''}`}
            style={{
              fontSize: 'clamp(28px, 7vw, 40px)',
              fontWeight: 800,
              color: 'var(--text-primary)',
              lineHeight: 1.1,
              letterSpacing: '-0.03em',
              marginBottom: '16px'
            }}
          >
            {formatAmount(netWorth, isPrivacyMasked)}
          </div>

          {/* Sub-metrics: Assets vs Liabilities */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
            <div>
              <span style={{ fontSize: '11px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.04em', display: 'block' }}>
                Liquid Assets
              </span>
              <span className={`font-mono ${isPrivacyMasked ? 'privacy-masked' : ''}`} style={{ fontSize: '15px', fontWeight: 600, color: 'var(--accent-emerald-light)' }}>
                {formatAmount(totalAssets, isPrivacyMasked)}
              </span>
            </div>

            <div style={{ width: '1px', height: '24px', background: 'var(--border-subtle)' }} />

            <div>
              <span style={{ fontSize: '11px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.04em', display: 'block' }}>
                Liabilities / Cards
              </span>
              <span className={`font-mono ${isPrivacyMasked ? 'privacy-masked' : ''}`} style={{ fontSize: '15px', fontWeight: 600, color: 'var(--accent-rose-light)' }}>
                {formatAmount(totalLiabilities, isPrivacyMasked)}
              </span>
            </div>
          </div>
        </div>

        {/* Right: Monthly Cash Flow Snapshot & Quick Actions */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px', width: '100%', maxWidth: '440px' }}>
          
          {/* Cash flow card */}
          <div
            style={{
              background: 'rgba(0, 0, 0, 0.25)',
              border: '1px solid var(--border-subtle)',
              borderRadius: 'var(--radius-md)',
              padding: '10px 14px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              gap: '12px',
              boxSizing: 'border-box'
            }}
          >
            <div>
              <div style={{ fontSize: '11px', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                <ArrowUpRight size={13} color="var(--accent-emerald)" />
                Income
              </div>
              <div className={`font-mono ${isPrivacyMasked ? 'privacy-masked' : ''}`} style={{ fontSize: '14px', fontWeight: 600, color: 'var(--accent-emerald-light)' }}>
                +{formatAmount(monthlyIncome, isPrivacyMasked)}
              </div>
            </div>

            <div style={{ width: '1px', height: '22px', background: 'var(--border-subtle)' }} />

            <div>
              <div style={{ fontSize: '11px', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                <ArrowDownRight size={13} color="var(--accent-rose)" />
                Expense
              </div>
              <div className={`font-mono ${isPrivacyMasked ? 'privacy-masked' : ''}`} style={{ fontSize: '14px', fontWeight: 600, color: 'var(--accent-rose-light)' }}>
                -{formatAmount(monthlyExpense, isPrivacyMasked)}
              </div>
            </div>

            <div style={{ width: '1px', height: '22px', background: 'var(--border-subtle)' }} />

            <div>
              <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>
                Savings
              </div>
              <div className="font-mono" style={{ fontSize: '14px', fontWeight: 700, color: '#38bdf8' }}>
                {savingsRate}%
              </div>
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div style={{ display: 'flex', gap: '10px' }}>
            <button
              onClick={onOpenVoiceModal}
              className="btn-secondary"
              style={{
                background: 'rgba(16, 185, 129, 0.12)',
                borderColor: 'rgba(16, 185, 129, 0.35)',
                color: 'var(--accent-emerald-light)'
              }}
            >
              <Mic size={15} />
              <span>Voice Log</span>
            </button>
            <button
              onClick={onOpenTransactionModal}
              className="btn-primary"
            >
              <Plus size={15} />
              <span>Add Transaction</span>
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
