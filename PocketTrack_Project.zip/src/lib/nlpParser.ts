import type { Account, Category, TransactionType } from '../db/types';

export interface ParsedVoiceTransaction {
  amount?: number;
  type: TransactionType;
  categoryId?: string;
  categoryName?: string;
  accountId?: string;
  accountName?: string;
  toAccountId?: string;
  toAccountName?: string;
  notes: string;
  confidence: number;
}

// Spoken numbers
const WORD_TO_NUMBER: Record<string, number> = {
  zero: 0, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9,
  ten: 10, eleven: 11, twelve: 12, thirteen: 13, fourteen: 14, fifteen: 15, sixteen: 16,
  seventeen: 17, eighteen: 18, nineteen: 19, twenty: 20, thirty: 30, forty: 40, fifty: 50,
  sixty: 60, seventy: 70, eighty: 80, ninety: 90, hundred: 100, thousand: 1000,
  lakh: 100000, lac: 100000, crore: 10000000, a: 1, an: 1
};

export function parseNaturalLanguageInput(
  rawInput: string,
  categories: Category[],
  accounts: Account[]
): ParsedVoiceTransaction {
  const text = rawInput.trim();
  const lowerText = text.toLowerCase();

  // 1. Detect Transaction Type
  let type: TransactionType = 'expense';
  if (
    lowerText.includes('transfer') ||
    lowerText.includes('moved') ||
    (lowerText.includes('from') && lowerText.includes('to') && (lowerText.includes('savings') || lowerText.includes('checking') || lowerText.includes('fd')))
  ) {
    type = 'transfer';
  } else if (
    lowerText.includes('received') ||
    lowerText.includes('got paid') ||
    lowerText.includes('earned') ||
    lowerText.includes('deposit') ||
    lowerText.includes('credited') ||
    lowerText.includes('salary') ||
    lowerText.includes('income') ||
    lowerText.includes('cashback') ||
    lowerText.includes('dividend')
  ) {
    type = 'income';
  }

  // 2. Extract Amount (Handles ₹, Rs, INR, k, lakh, decimals)
  let amount: number | undefined;

  // Pattern: "50k", "2.5k", "1.5 lakh", "500 rs", "₹1200", "1200 rupees"
  const lakhMatch = lowerText.match(/(\d+(?:\.\d+)?)\s*(?:lakh|lakhs|lac|lacs)/i);
  const kMatch = lowerText.match(/(\d+(?:\.\d+)?)\s*k\b/i);
  const standardNumericMatch = lowerText.match(/(?:[₹$€£]|rs\.?|inr)?\s*(\d+(?:\.\d{1,2})?)(?:\s*(?:rupees|rupee|rs|bucks|dollars|inr))?/i);

  if (lakhMatch && lakhMatch[1]) {
    amount = parseFloat(lakhMatch[1]) * 100000;
  } else if (kMatch && kMatch[1]) {
    amount = parseFloat(kMatch[1]) * 1000;
  } else if (standardNumericMatch && standardNumericMatch[1]) {
    amount = parseFloat(standardNumericMatch[1]);
  } else {
    // Word-based parsing
    const words = lowerText.split(/\s+/);
    let totalWordSum = 0;
    let currentPart = 0;
    let foundNumber = false;

    for (const w of words) {
      const cleanW = w.replace(/[^a-z]/g, '');
      if (WORD_TO_NUMBER[cleanW] !== undefined) {
        foundNumber = true;
        const val = WORD_TO_NUMBER[cleanW];
        if (val === 100) {
          currentPart = (currentPart || 1) * 100;
        } else if (val === 1000) {
          totalWordSum += (currentPart || 1) * 1000;
          currentPart = 0;
        } else if (val === 100000) {
          totalWordSum += (currentPart || 1) * 100000;
          currentPart = 0;
        } else {
          currentPart += val;
        }
      } else if (foundNumber && (cleanW === 'rupees' || cleanW === 'rupee' || cleanW === 'rs' || cleanW === 'dollars')) {
        break;
      }
    }
    totalWordSum += currentPart;
    if (foundNumber && totalWordSum > 0) {
      amount = totalWordSum;
    }
  }

  // 3. Match Account (including UPI, GPay, PhonePe, Paytm, HDFC, SBI, ICICI, etc.)
  let matchedAccount: Account | undefined;
  let matchedToAccount: Account | undefined;

  for (const acc of accounts) {
    const accName = acc.name.toLowerCase();
    const accType = acc.type.toLowerCase();

    if (lowerText.includes(accName) || lowerText.includes(accType)) {
      if (!matchedAccount) {
        matchedAccount = acc;
      } else if (type === 'transfer' && matchedAccount.id !== acc.id) {
        matchedToAccount = acc;
      }
    }
  }

  // Common aliases
  if (!matchedAccount) {
    if (lowerText.includes('upi') || lowerText.includes('gpay') || lowerText.includes('phonepe') || lowerText.includes('paytm')) {
      // Default to checking or cash for UPI
      matchedAccount = accounts.find(a => a.type === 'checking') || accounts.find(a => a.type === 'cash');
    } else if (lowerText.includes('card') || lowerText.includes('credit')) {
      matchedAccount = accounts.find(a => a.type === 'credit');
    } else if (lowerText.includes('cash') || lowerText.includes('wallet')) {
      matchedAccount = accounts.find(a => a.type === 'cash');
    } else if (lowerText.includes('savings') || lowerText.includes('fd')) {
      matchedAccount = accounts.find(a => a.type === 'savings');
    } else if (lowerText.includes('bank') || lowerText.includes('checking') || lowerText.includes('salary')) {
      matchedAccount = accounts.find(a => a.type === 'checking');
    }
  }

  if (!matchedAccount && accounts.length > 0) {
    matchedAccount = accounts.find(a => a.type === 'checking') || accounts[0];
  }

  // 4. Match Category (including Indian categories: Chai, Kirana, Swiggy, Zomato, Auto, Metro, Petrol)
  let matchedCategory: Category | undefined;
  const filteredCategories = categories.filter(c => c.type === type);

  const keywordCategoryMap: Record<string, string[]> = {
    'cat-food': ['chai', 'coffee', 'tea', 'lunch', 'dinner', 'breakfast', 'swiggy', 'zomato', 'restaurant', 'cafe', 'biryani', 'pizza', 'snacks', 'eating', 'food'],
    'cat-groceries': ['kirana', 'blinkit', 'zepto', 'instamart', 'groceries', 'vegetables', 'sabzi', 'milk', 'fruit', 'supermarket', 'd mart', 'ration'],
    'cat-housing': ['rent', 'maintenance', 'electricity', 'flat', 'apartment', 'house rent'],
    'cat-transport': ['auto', 'rickshaw', 'cab', 'uber', 'ola', 'rapido', 'metro', 'petrol', 'fuel', 'diesel', 'toll', 'bus', 'train', 'irctc'],
    'cat-utilities': ['wifi', 'broadband', 'electricity bill', 'water bill', 'cylinder', 'gas', 'recharge', 'mobile bill', 'airtel', 'jio'],
    'cat-entertainment': ['movie', 'bookmyshow', 'pvr', 'theatre', 'gaming', 'concert', 'outing'],
    'cat-tech': ['netflix', 'spotify', 'prime', 'hotstar', 'youtube', 'chatgpt', 'software'],
    'cat-health': ['apollo', 'pharmacy', 'medicine', 'doctor', 'clinic', 'hospital', 'gym', 'cult'],
    'cat-shopping': ['amazon', 'flipkart', 'myntra', 'clothes', 'shoes', 'electronics', 'mall', 'shopping'],
    'cat-salary': ['salary', 'paycheck', 'bonus', 'stipend', 'incentive'],
    'cat-freelance': ['client', 'freelance', 'project', 'consulting', 'gig'],
    'cat-investments': ['sip', 'mutual fund', 'zerodha', 'groww', 'stocks', 'dividend', 'fd interest', 'crypto']
  };

  // Direct name match
  for (const cat of filteredCategories) {
    if (lowerText.includes(cat.name.toLowerCase())) {
      matchedCategory = cat;
      break;
    }
  }

  // Keyword match
  if (!matchedCategory) {
    for (const [catId, keywords] of Object.entries(keywordCategoryMap)) {
      for (const kw of keywords) {
        if (new RegExp(`\\b${kw}\\b`, 'i').test(lowerText)) {
          matchedCategory = categories.find(c => c.id === catId);
          if (matchedCategory) break;
        }
      }
      if (matchedCategory) break;
    }
  }

  if (!matchedCategory && type !== 'transfer') {
    matchedCategory = type === 'expense'
      ? categories.find(c => c.id === 'cat-food') || filteredCategories[0]
      : categories.find(c => c.id === 'cat-salary') || filteredCategories[0];
  }

  // 5. Clean Description / Notes
  let notes = text;
  notes = notes
    .replace(/^(?:please\s+)?(?:can\s+you\s+)?(?:log|add|record|spent|i\s+spent|paid|bought|received|credited)\s+/i, '')
    .replace(/(?:from|with|using|into|to|via)\s+(?:my\s+)?(?:upi|gpay|phonepe|paytm|checking|savings|card|credit\s+card|cash|wallet)\b/gi, '')
    .replace(/(?:for|of)?\s*(?:[₹$€£]|rs\.?|inr)?\s*\d+(?:\.\d{1,2})?(?:\s*(?:rupees|rupee|rs|bucks|dollars|cents|k|lakh|lakhs))?/gi, '')
    .trim();

  if (notes.length > 0) {
    notes = notes.charAt(0).toUpperCase() + notes.slice(1);
  } else {
    notes = matchedCategory ? matchedCategory.name : 'Quick Log';
  }

  return {
    amount: amount ? Math.round(amount * 100) / 100 : undefined,
    type,
    categoryId: matchedCategory?.id,
    categoryName: matchedCategory?.name,
    accountId: matchedAccount?.id,
    accountName: matchedAccount?.name,
    toAccountId: matchedToAccount?.id,
    toAccountName: matchedToAccount?.name,
    notes,
    confidence: amount !== undefined ? 0.95 : 0.6
  };
}
