import { parseNaturalLanguageInput } from './nlpParser';
import { DEFAULT_CATEGORIES, DEFAULT_ACCOUNTS } from '../db/defaultData';

const categories = DEFAULT_CATEGORIES as any;
const accounts = DEFAULT_ACCOUNTS as any;

const testCases = [
  {
    input: 'Spent 20 rupees on chai with cash',
    expectedAmount: 20,
    expectedType: 'expense',
    expectedCategory: 'cat-food'
  },
  {
    input: 'Paid 650 for Swiggy with credit card',
    expectedAmount: 650,
    expectedType: 'expense',
    expectedCategory: 'cat-food'
  },
  {
    input: 'Received 85000 salary into savings',
    expectedAmount: 85000,
    expectedType: 'income',
    expectedCategory: 'cat-salary'
  },
  {
    input: 'Spent 1.5 lakh on bike',
    expectedAmount: 150000,
    expectedType: 'expense'
  },
  {
    input: 'Transferred 15k from checking to savings',
    expectedAmount: 15000,
    expectedType: 'transfer'
  },
  {
    input: '₹450 for Blinkit groceries',
    expectedAmount: 450,
    expectedType: 'expense',
    expectedCategory: 'cat-groceries'
  }
];

let allPassed = true;

for (const tc of testCases) {
  const res = parseNaturalLanguageInput(tc.input, categories, accounts);
  const amountOk = res.amount === tc.expectedAmount;
  const typeOk = res.type === tc.expectedType;
  const catOk = !tc.expectedCategory || res.categoryId === tc.expectedCategory;

  if (amountOk && typeOk && catOk) {
    console.log(`[PASS] "${tc.input}" -> Amount: ₹${res.amount}, Type: ${res.type}, Category: ${res.categoryName || 'N/A'}`);
  } else {
    console.error(`[FAIL] "${tc.input}" -> Result:`, res);
    allPassed = false;
  }
}

if (allPassed) {
  console.log('\n>>> ALL INDIAN RUPEE & NLP TESTS PASSED! <<<');
} else {
  throw new Error('Some tests failed');
}
