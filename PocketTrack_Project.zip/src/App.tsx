import { useState, useMemo } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from './db';
import { useAccounts } from './hooks/useAccounts';
import { useTransactions } from './hooks/useTransactions';
import { useBudgets } from './hooks/useBudgets';
import { PrivacyProvider } from './context/PrivacyContext';
import { AuthProvider } from './context/AuthContext';
import { SyncProvider } from './context/SyncContext';
import { CurrencyProvider } from './context/CurrencyContext';
import { LanguageProvider, useLanguage } from './context/LanguageContext';

import { Header } from './components/layout/Header';
import { Sidebar, type NavTab } from './components/layout/Sidebar';
import { BottomNav } from './components/layout/BottomNav';
import { MobileFrameWrapper } from './components/mobile/MobileFrameWrapper';

import { WelcomeExplainer } from './components/welcome/WelcomeExplainer';
import { AuthLanding } from './components/welcome/AuthLanding';
import { BalanceMathGuide } from './components/dashboard/BalanceMathGuide';
import { GettingStartedCard } from './components/dashboard/GettingStartedCard';
import { BankCardCarousel } from './components/dashboard/BankCardCarousel';
import { QuickTapBar } from './components/dashboard/QuickTapBar';
import { NetWorthHero } from './components/dashboard/NetWorthHero';
import { FinancialHealthScore } from './components/dashboard/FinancialHealthScore';
import { RecentTransactions } from './components/dashboard/RecentTransactions';
import { BudgetProgressOverview } from './components/dashboard/BudgetProgressOverview';

import { TransactionHistoryView } from './components/transactions/TransactionHistoryView';
import { AccountsView } from './components/accounts/AccountsView';
import { BudgetsView } from './components/budgets/BudgetsView';
import { AnalyticsView } from './components/analytics/AnalyticsView';
import { SavingsGoalsView } from './components/goals/SavingsGoalsView';
import { WealthSimulatorView } from './components/wealth/WealthSimulatorView';
import { SubscriptionsRadarView } from './components/subscriptions/SubscriptionsRadarView';

import { VoiceLogModal } from './components/transactions/VoiceLogModal';
import { TransactionModal } from './components/transactions/TransactionModal';
import { TransferModal } from './components/transactions/TransferModal';
import { AuthModal } from './components/auth/AuthModal';
import { OnboardingTour } from './components/onboarding/OnboardingTour';

import './App.css';

interface MainAppProps {
  onReopenExplainer: () => void;
}

function MainApp({ onReopenExplainer }: MainAppProps) {
  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');
  const [isMobileFrame, setIsMobileFrame] = useState<boolean>(() => {
    return localStorage.getItem('pockettrack_mobile_frame') === 'true';
  });
  
  // Modals state
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState<boolean>(false);
  const [isTransactionModalOpen, setIsTransactionModalOpen] = useState<boolean>(false);
  const [isTransferModalOpen, setIsTransferModalOpen] = useState<boolean>(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [isTourOpen, setIsTourOpen] = useState<boolean>(() => {
    return localStorage.getItem('pockettrack_tour_completed') !== 'true';
  });

  const { t } = useLanguage();

  // Core Data Hooks
  const { accounts, netWorth, totalAssets, totalLiabilities, addAccount, deleteAccount } = useAccounts();
  const { transactions, addTransaction, deleteTransaction } = useTransactions();
  const { budgetStatuses, updateCategoryBudget } = useBudgets();
  const categories = useLiveQuery(() => db.categories.toArray()) || [];

  // Monthly stats calculation
  const { monthlyIncome, monthlyExpense } = useMemo(() => {
    const now = new Date();
    const currentMonthPrefix = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

    let income = 0;
    let expense = 0;

    transactions.forEach(tx => {
      if (tx.date.startsWith(currentMonthPrefix)) {
        if (tx.type === 'income') income += tx.amount;
        if (tx.type === 'expense') expense += tx.amount;
      }
    });

    return { monthlyIncome: income, monthlyExpense: expense };
  }, [transactions]);

  const toggleMobileFrame = () => {
    setIsMobileFrame(prev => {
      const next = !prev;
      localStorage.setItem('pockettrack_mobile_frame', String(next));
      return next;
    });
  };

  // Page titles localized
  const pageTitles: Record<NavTab, string> = {
    dashboard: t.executiveDashboard,
    transactions: t.activityHistory,
    accounts: t.accountsVault,
    budgets: t.budgetsLimits,
    analytics: t.cashFlowInsights,
    goals: t.savingsGoals,
    simulator: t.wealthSimulator,
    subscriptions: t.subscriptionsRadar
  };

  const handleTransfer = async (data: {
    fromAccountId: string;
    toAccountId: string;
    amount: number;
    notes?: string;
  }) => {
    await addTransaction({
      amount: data.amount,
      type: 'transfer',
      accountId: data.fromAccountId,
      toAccountId: data.toAccountId,
      notes: data.notes
    });
  };

  const handleQuickLog = async (data: {
    amount: number;
    notes: string;
    categoryId: string;
    accountId: string;
    type?: 'income' | 'expense';
  }) => {
    const targetAccount = accounts.find(a => a.id === data.accountId) || accounts[0];
    if (!targetAccount) return;

    await addTransaction({
      amount: data.amount,
      type: data.type || 'expense',
      accountId: targetAccount.id,
      categoryId: data.categoryId,
      notes: data.notes
    });
  };

  return (
    <MobileFrameWrapper isMobileFrame={isMobileFrame}>
      <div className={`app-container ${isMobileFrame ? 'mobile-mode-active' : ''}`}>
        {/* Desktop Sidebar (hidden when mobile frame is active or screen is small) */}
        {!isMobileFrame && (
          <Sidebar
            currentTab={currentTab}
            onSelectTab={setCurrentTab}
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
          />
        )}

        {/* Main Viewport */}
        <main className="main-viewport">
          <Header
            pageTitle={pageTitles[currentTab]}
            onOpenVoiceModal={() => setIsVoiceModalOpen(true)}
            onOpenTransactionModal={() => setIsTransactionModalOpen(true)}
            onOpenTour={() => setIsTourOpen(true)}
            onReopenExplainer={onReopenExplainer}
            isMobileFrame={isMobileFrame}
            onToggleMobileFrame={toggleMobileFrame}
          />

          <div className="content-container">
            {currentTab === 'dashboard' && (
              <>
                {/* Interactive "How It Works: Automatic Balance Math" Guide */}
                <BalanceMathGuide
                  primaryAccount={accounts[0]}
                  monthlyIncome={monthlyIncome}
                  monthlyExpense={monthlyExpense}
                  netWorth={netWorth}
                  onQuickLog={async (data) => {
                    await handleQuickLog({
                      amount: data.amount,
                      type: data.type,
                      accountId: data.accountId,
                      categoryId: data.categoryId,
                      notes: data.notes
                    });
                  }}
                />

                {/* Getting Started First Steps Checklist */}
                <GettingStartedCard
                  hasTransactions={transactions.length > 0}
                  onOpenVoiceModal={() => setIsVoiceModalOpen(true)}
                  onSelectTab={setCurrentTab}
                />

                {/* Bank Card Carousel (Authentic Digital Wallet) */}
                <BankCardCarousel
                  accounts={accounts}
                  onOpenTransfer={() => setIsTransferModalOpen(true)}
                />

                {/* Instant 1-Tap Log Bar */}
                <QuickTapBar onQuickLog={handleQuickLog} />

                {/* Net Worth Hero */}
                <NetWorthHero
                  netWorth={netWorth}
                  totalAssets={totalAssets}
                  totalLiabilities={totalLiabilities}
                  monthlyIncome={monthlyIncome}
                  monthlyExpense={monthlyExpense}
                  onOpenVoiceModal={() => setIsVoiceModalOpen(true)}
                  onOpenTransactionModal={() => setIsTransactionModalOpen(true)}
                />

                {/* Financial Health Score & Streaks */}
                <div style={{ marginBottom: '24px' }}>
                  <FinancialHealthScore
                    netWorth={netWorth}
                    totalAssets={totalAssets}
                    totalLiabilities={totalLiabilities}
                    monthlyIncome={monthlyIncome}
                    monthlyExpense={monthlyExpense}
                  />
                </div>

                {/* Recent Transactions & Monthly Budgets */}
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '20px' }}>
                  <RecentTransactions
                    transactions={transactions}
                    categories={categories}
                    accounts={accounts}
                    onDelete={deleteTransaction}
                    onViewAll={() => setCurrentTab('transactions')}
                  />
                  <BudgetProgressOverview
                    budgetStatuses={budgetStatuses}
                    onViewBudgets={() => setCurrentTab('budgets')}
                  />
                </div>
              </>
            )}

            {currentTab === 'transactions' && (
              <TransactionHistoryView
                transactions={transactions}
                categories={categories}
                accounts={accounts}
                onDelete={deleteTransaction}
                onOpenNewTransaction={() => setIsTransactionModalOpen(true)}
                onOpenVoiceLog={() => setIsVoiceModalOpen(true)}
              />
            )}

            {currentTab === 'accounts' && (
              <AccountsView
                accounts={accounts}
                netWorth={netWorth}
                totalAssets={totalAssets}
                totalLiabilities={totalLiabilities}
                onAddAccount={addAccount}
                onDeleteAccount={deleteAccount}
                onOpenTransferModal={() => setIsTransferModalOpen(true)}
              />
            )}

            {currentTab === 'budgets' && (
              <BudgetsView
                budgetStatuses={budgetStatuses}
                allCategories={categories}
                onUpdateLimit={updateCategoryBudget}
              />
            )}

            {currentTab === 'analytics' && (
              <AnalyticsView
                transactions={transactions}
                categories={categories}
              />
            )}

            {currentTab === 'goals' && (
              <SavingsGoalsView />
            )}

            {currentTab === 'simulator' && (
              <WealthSimulatorView />
            )}

            {currentTab === 'subscriptions' && (
              <SubscriptionsRadarView />
            )}
          </div>
        </main>

        {/* Mobile Bottom Navigation (shown on mobile or when Phone Frame is active) */}
        <BottomNav
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          onOpenVoiceModal={() => setIsVoiceModalOpen(true)}
          isMobileFrame={isMobileFrame}
        />

        {/* Modals */}
        <VoiceLogModal
          isOpen={isVoiceModalOpen}
          onClose={() => setIsVoiceModalOpen(false)}
          categories={categories}
          accounts={accounts}
          onSave={addTransaction}
        />

        <TransactionModal
          isOpen={isTransactionModalOpen}
          onClose={() => setIsTransactionModalOpen(false)}
          categories={categories}
          accounts={accounts}
          onSave={addTransaction}
        />

        <TransferModal
          isOpen={isTransferModalOpen}
          onClose={() => setIsTransferModalOpen(false)}
          accounts={accounts}
          onTransfer={handleTransfer}
        />

        <AuthModal
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
        />

        <OnboardingTour
          isOpen={isTourOpen}
          onClose={() => setIsTourOpen(false)}
        />
      </div>
    </MobileFrameWrapper>
  );
}

type AppStage = 'explainer' | 'auth' | 'app';

function RootApp() {
  const [stage, setStage] = useState<AppStage>(() => {
    const saved = localStorage.getItem('pockettrack_stage');
    if (saved === 'app' || saved === 'auth' || saved === 'explainer') {
      return saved;
    }
    return 'explainer';
  });

  const handleEnterApp = async (userData: { name: string; startingBalance: number; accountName: string }) => {
    await db.initializeCleanVault(userData.name, userData.accountName, userData.startingBalance);
    localStorage.setItem('pockettrack_stage', 'app');
    setStage('app');
  };

  const handleQuickStartGuest = async () => {
    await db.initializeCleanVault('Guest User', 'UPI Wallet & Cash', 2000);
    localStorage.setItem('pockettrack_stage', 'app');
    setStage('app');
  };

  if (stage === 'explainer') {
    return (
      <WelcomeExplainer
        onContinueToAuth={() => {
          localStorage.setItem('pockettrack_stage', 'auth');
          setStage('auth');
        }}
        onQuickStartGuest={handleQuickStartGuest}
      />
    );
  }

  if (stage === 'auth') {
    return (
      <AuthLanding
        onBackToExplainer={() => {
          localStorage.setItem('pockettrack_stage', 'explainer');
          setStage('explainer');
        }}
        onEnterApp={handleEnterApp}
      />
    );
  }

  return <MainApp onReopenExplainer={() => setStage('explainer')} />;
}

export default function App() {
  return (
    <LanguageProvider>
      <CurrencyProvider>
        <PrivacyProvider>
          <AuthProvider>
            <SyncProvider>
              <RootApp />
            </SyncProvider>
          </AuthProvider>
        </PrivacyProvider>
      </CurrencyProvider>
    </LanguageProvider>
  );
}
