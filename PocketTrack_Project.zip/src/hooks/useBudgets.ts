import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../db';
import type { Category } from '../db/types';

export interface CategoryBudgetStatus {
  category: Category;
  limit: number;
  spent: number;
  remaining: number;
  percentage: number;
  isOverBudget: boolean;
  isNearLimit: boolean;
}

export function useBudgets() {
  const categories = useLiveQuery(() => db.categories.where('type').equals('expense').toArray()) || [];

  const budgetStatuses = useLiveQuery(async (): Promise<CategoryBudgetStatus[]> => {
    const expenseCats = await db.categories.where('type').equals('expense').toArray();

    // Start and end of current month
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
    const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999).toISOString();

    const monthlyTransactions = await db.transactions
      .where('date')
      .between(startOfMonth, endOfMonth)
      .toArray();

    return expenseCats
      .filter(cat => cat.budgetLimit && cat.budgetLimit > 0)
      .map(cat => {
        const spent = monthlyTransactions
          .filter(tx => tx.categoryId === cat.id && tx.type === 'expense')
          .reduce((sum, tx) => sum + tx.amount, 0);

        const limit = cat.budgetLimit || 0;
        const remaining = Math.max(0, limit - spent);
        const percentage = limit > 0 ? (spent / limit) * 100 : 0;

        return {
          category: cat,
          limit,
          spent,
          remaining,
          percentage,
          isOverBudget: spent > limit,
          isNearLimit: percentage >= 80 && spent <= limit
        };
      })
      .sort((a, b) => b.percentage - a.percentage);
  }, []) || [];

  const updateCategoryBudget = async (categoryId: string, limit: number) => {
    await db.categories.update(categoryId, { budgetLimit: limit });
  };

  return {
    categories,
    budgetStatuses,
    updateCategoryBudget
  };
}
