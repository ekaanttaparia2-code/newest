import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../db';
import type { Account, AccountType } from '../db/types';

export function useAccounts() {
  const accounts = useLiveQuery(async () => {
    const all = await db.accounts.toArray();
    return all.filter(acc => !acc.isArchived);
  }) || [];

  const netWorth = accounts.reduce((sum, acc) => sum + acc.balance, 0);

  const totalAssets = accounts
    .filter(acc => acc.balance > 0)
    .reduce((sum, acc) => sum + acc.balance, 0);

  const totalLiabilities = accounts
    .filter(acc => acc.balance < 0)
    .reduce((sum, acc) => sum + Math.abs(acc.balance), 0);

  const addAccount = async (accountData: {
    name: string;
    type: AccountType;
    balance: number;
    currency?: string;
    color?: string;
    icon?: string;
    institution?: string;
  }) => {
    const id = `acc-${Date.now()}`;
    const newAccount: Account = {
      id,
      name: accountData.name,
      type: accountData.type,
      balance: accountData.balance,
      currency: accountData.currency || 'INR',
      color: accountData.color || '#3b82f6',
      icon: accountData.icon || 'CreditCard',
      institution: accountData.institution || '',
      isArchived: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    await db.accounts.add(newAccount);
    return newAccount;
  };

  const updateAccount = async (id: string, updates: Partial<Account>) => {
    await db.accounts.update(id, {
      ...updates,
      updatedAt: new Date().toISOString()
    });
  };

  const deleteAccount = async (id: string) => {
    // Soft delete / archive
    await db.accounts.update(id, {
      isArchived: true,
      updatedAt: new Date().toISOString()
    });
  };

  return {
    accounts,
    netWorth,
    totalAssets,
    totalLiabilities,
    addAccount,
    updateAccount,
    deleteAccount
  };
}
